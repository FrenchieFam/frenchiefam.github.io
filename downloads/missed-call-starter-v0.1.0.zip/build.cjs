'use strict';
const fs=require('node:fs');const path=require('node:path');const {decide}=require('./decision.cjs');
const sample={DialCallStatus:'no-answer',CallSid:'SIMULATED_CALL_001',From:'+12025550101',To:'+12025550102',businessName:'Example Handyman',optedOut:false,permissionConfirmed:true,alreadyProcessed:false};
const workflow={name:'Missed call — simulation only',active:false,nodes:[
 {parameters:{},id:'manual-demo',name:'Run simulation',type:'n8n-nodes-base.manualTrigger',typeVersion:1,position:[0,0]},
 {parameters:{mode:'runOnceForAllItems',jsCode:'// Fictional input only. Edit these values to try a scenario.\nreturn [{ json: '+JSON.stringify(sample,null,2)+' }];'},id:'sample-event',name:'Fictional call event',type:'n8n-nodes-base.code',typeVersion:2,position:[260,0]},
 {parameters:{mode:'runOnceForAllItems',jsCode:decide.toString()+'\nreturn $input.all().map(item => ({ json: decide(item.json) }));'},id:'draft-only',name:'Draft only — no SMS sent',type:'n8n-nodes-base.code',typeVersion:2,position:[520,0]}
],connections:{'Run simulation':{main:[[{node:'Fictional call event',type:'main',index:0}]]},'Fictional call event':{main:[[{node:'Draft only — no SMS sent',type:'main',index:0}]]}},settings:{executionOrder:'v1'},pinData:{},tags:[]};
fs.writeFileSync(path.join(__dirname,'workflow.simulation.json'),JSON.stringify(workflow,null,2)+'\n');
const source=fs.readFileSync(path.join(__dirname,'demo.template.html'),'utf8').replace('/* DECISION_FUNCTION */',decide.toString());
fs.writeFileSync(path.join(__dirname,'demo.html'),source);
console.log('Built offline demo and inactive manual n8n workflow.');
