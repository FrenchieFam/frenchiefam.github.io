'use strict';
const assert = require('node:assert/strict');
const {decide} = require('./decision.cjs');
const base = { DialCallStatus: 'no-answer', CallSid: 'SIMULATED_CALL_001', From: '+12025550101', To: '+12025550102', businessName: 'Example Handyman', optedOut: false, permissionConfirmed: true, alreadyProcessed: false };
const cases = [
 ['missed dial prepares draft', base, 'draft'],
 ['busy prepares draft', {...base,DialCallStatus:'busy'}, 'draft'],
 ['answered dial does not prepare draft', {...base,DialCallStatus:'completed'}, 'skip'],
 ['failure is not automatically classified as missed', {...base,DialCallStatus:'failed'}, 'skip'],
 ['parent call status cannot substitute for dial status', {...base,DialCallStatus:undefined,CallStatus:'no-answer'}, 'invalid'],
 ['anonymous caller', {...base,From:'anonymous'}, 'invalid'],
 ['duplicate call', {...base,alreadyProcessed:true}, 'blocked'],
 ['unknown duplicate state', {...base,alreadyProcessed:undefined}, 'blocked'],
 ['opted-out caller', {...base,optedOut:true}, 'blocked'],
 ['unknown opt-out state', {...base,optedOut:undefined}, 'blocked'],
 ['unconfirmed permission', {...base,permissionConfirmed:false}, 'blocked'],
 ['missing call ID', {...base,CallSid:''}, 'invalid'],
 ['same caller and business', {...base,To:base.From}, 'invalid'],
 ['missing business name', {...base,businessName:''}, 'invalid'],
 ['bad event', null, 'invalid'],
];
for(const [name,input,outcome] of cases){const result=decide(input);assert.equal(result.outcome,outcome,name);assert.equal(result.smsSent,false,name);}
assert.equal(decide(base).draft.to,base.From);
assert.equal(decide(base).draft.from,base.To);
assert.equal(decide(base).deduplicationKey,'missed-call:'+base.CallSid);
console.log(`${cases.length} decision cases passed, plus recipient, sender, and deduplication-key checks.`);
if(process.argv.includes('--demo'))console.log(JSON.stringify(decide(base),null,2));
