# A future connected version — separate scope

The starter ends at a simulated draft. A live implementation would need decisions
and verification in each of these areas; none is supplied as a working service.

1. Call flow: select a provider/number, design forwarding and dial-result callbacks.
   Decide how voicemail and failed/canceled calls should be handled.
2. Trusted input: verify actual provider webhook signatures before using events.
3. Persistent state: durable duplicate keys, repeat-caller rate limits, explicit
   retry/error states and transaction behavior under simultaneous callbacks.
4. Messaging eligibility: actual permission and opt-out processes, supported
   destination capabilities, reply/STOP processing and suppression storage.
5. Delivery: a provider sandbox/test account, controlled end-to-end cases,
   delivery failure handling and logs that avoid exposing customer information.
6. Operations: disclose number/provider/hosting costs, monitoring, support and
   retention/deletion decisions before launch.

These are engineering scope items, not legal advice or a compliance guarantee.
No provider purchase, account connection or real message is required for this lab.

Primary call-flow reference: https://www.twilio.com/docs/voice/twiml/dial
