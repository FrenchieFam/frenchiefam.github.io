# Missed Call Workflow Lab — v0.1.0

An offline learning starter by FrenchieFam. Try the decisions before connecting a
phone system. This package never calls or texts anyone and has no provider account.

## Fast start (no installation)

1. Extract the ZIP.
2. Open demo.html in a modern browser. No web server is needed.
3. Try Nobody answers, then Caller has opted out, then Call completed.
4. Watch the draft change or disappear. Messages sent stays zero.

The business name and telephone numbers are fictional. Don't put customer data
or passwords into the demo. Nothing in this starter stores or transmits the form.

## Optional developer steps

With Node.js installed, run:
    node test.cjs
    node test-workflow.cjs
    node build.cjs

15 decision scenarios plus output checks passed. The exact generated workflow
JavaScript was exercised with 11 scenarios in Node. This is not evidence of import
or execution inside a running n8n instance; that step remains unverified.

## What's inside

- demo.html: standalone interactive lab.
- decision.cjs: pure decision function.
- workflow.simulation.json: inactive Manual Trigger → fictional event → draft only.
- demo.template.html / build.cjs: editable source and generator.
- test.cjs / test-workflow.cjs: local verification.
- N8N-GUIDE.md: import instructions and expected outputs.
- SCENARIOS.csv: expected behavior for quick review.
- LIVE-VERSION-PLAN.md: integration gaps, separate from this starter.
- LICENSE.txt: MIT license for the code and included documentation.
- SHA256SUMS.json: file integrity manifest, excluding itself.

This is an educational prototype. It is not a finished missed-call SMS service,
a compliance solution, a durable duplicate database, or evidence of customer ROI.

Project and contact: https://frenchiefam.dev/automation/
