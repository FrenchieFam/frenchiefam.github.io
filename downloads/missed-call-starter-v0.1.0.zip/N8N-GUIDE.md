# Optional n8n walkthrough

Status: generated JSON and embedded code tested locally in Node. Import/runtime
inside n8n has NOT been verified. No n8n account or subscription is included.
You can use demo.html without n8n.

1. In a disposable/test n8n workspace, create an empty workflow.
2. Use its workflow menu → Import from File and choose workflow.simulation.json.
3. Confirm the workflow is inactive and contains only three nodes:
   Run simulation → Fictional call event → Draft only — no SMS sent.
4. Execute manually. With the bundled fictional sample, expect outcome=draft,
   mode=simulation, smsSent=false, providerVerified=false.
5. In Fictional call event, change optedOut to true and run again. Expect blocked.
6. Try DialCallStatus=completed. Expect skip, including the voicemail caveat.

Edit the fictional event node, keeping the decision node separate. The final
node reads every incoming item through $input.all() and returns one result each.
There is no webhook, schedule, HTTP Request, SMS node, credential or activation.

A parent CallStatus field does not replace DialCallStatus in this example. Its
permission/opt-out/alreadyProcessed flags are assumptions, not real checks.
Do not attach a message-sending node and treat those assumptions as validation.

Record your actual n8n version and import/run result if testing this yourself.
An import error should be investigated before activation or live integration.

Official import guide:
https://docs.n8n.io/workflows/export-import/
