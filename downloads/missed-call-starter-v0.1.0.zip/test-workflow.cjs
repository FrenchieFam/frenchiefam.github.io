'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const {decide}=require('./decision.cjs');
const workflow=JSON.parse(fs.readFileSync(__dirname+'/workflow.simulation.json','utf8'));
assert.equal(workflow.active,false);
assert.equal(workflow.nodes.length,3);
assert.deepEqual(workflow.nodes.map(n=>n.type),['n8n-nodes-base.manualTrigger','n8n-nodes-base.code','n8n-nodes-base.code']);
for(const node of workflow.nodes)assert.equal(node.credentials,undefined);
const sampleNode=workflow.nodes[1],decisionNode=workflow.nodes[2];
assert.equal(workflow.connections['Run simulation'].main[0][0].node,sampleNode.name);
assert.equal(workflow.connections[sampleNode.name].main[0][0].node,decisionNode.name);
const execute=(code,items=[])=>JSON.parse(JSON.stringify(vm.runInNewContext('(function(){'+code+'})()',{$input:{all:()=>items}},{timeout:1000})));
const sample=execute(sampleNode.parameters.jsCode);
assert.equal(sample.length,1);
const base=sample[0].json;
const variants=[base,{...base,DialCallStatus:'busy'},{...base,DialCallStatus:'completed'},{...base,DialCallStatus:'failed'},{...base,optedOut:true},{...base,permissionConfirmed:false},{...base,alreadyProcessed:true},{...base,alreadyProcessed:undefined},{...base,From:'anonymous'},{...base,businessName:''},null];
const input=variants.map(json=>({json}));
const output=execute(decisionNode.parameters.jsCode,input);
assert.equal(output.length,input.length);
for(let i=0;i<variants.length;i++){
 assert.deepEqual(output[i].json,decide(variants[i]));
 assert.equal(output[i].json.smsSent,false);
}
assert.ok(fs.readFileSync(__dirname+'/demo.html','utf8').includes(decide.toString()));
console.log('Generated workflow structure and 11 embedded-code scenarios passed; offline demo embeds current logic.');
console.log('This executes the exported JavaScript in Node, not a running n8n instance.');
